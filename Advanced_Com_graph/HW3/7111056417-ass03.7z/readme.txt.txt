根據文字欄的提示輸入想要執行的功能。
1:Decimal to IEEE-754
2:IEEE-755 to Decimal
3:Finish
程式會自動偵測feature資料夾內的文件，並將其進行相對應的轉換。